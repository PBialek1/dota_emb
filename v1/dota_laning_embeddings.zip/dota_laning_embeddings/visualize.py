"""
visualize.py
------------
Interactive Plotly dashboard for DOTA 2 laning embeddings.

Generates a single self-contained HTML file with six panels:
  1. Colored by lane role
  2. Colored by hero   (top N most common in dataset)
  3. Colored by player (top N most active in dataset)
  4. Colored by cluster
  5. Cluster role composition (stacked bar)
  6. Silhouette score sweep (bar chart, best k highlighted)

The four scatter views are the core validation check:
if the embedding captured latent laning behaviour, role/hero/player
structure should emerge even though those labels were never input features.
"""

import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
from plotly.io import to_html
from typing import Dict, Optional
import logging

logger = logging.getLogger(__name__)

ROLE_NAMES = {
    1: "Safe Lane",
    2: "Mid Lane",
    3: "Off Lane",
    4: "Soft Support",
    5: "Hard Support",
}

ROLE_COLORS = {
    "Safe Lane":    "#2ecc71",
    "Mid Lane":     "#3498db",
    "Off Lane":     "#e74c3c",
    "Soft Support": "#f39c12",
    "Hard Support": "#9b59b6",
    "Unknown":      "#636e72",
}

_DARK_BG = "#0d1117"

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _build_viz_df(
    embedding: np.ndarray,
    metadata: pd.DataFrame,
    hero_lookup: Dict[int, str],
    cluster_labels: Optional[np.ndarray],
) -> pd.DataFrame:
    df = pd.DataFrame({"x": embedding[:, 0], "y": embedding[:, 1]})
    df["match_id"]   = metadata["match_id"].values
    df["account_id"] = metadata["account_id"].fillna(-1).astype("Int64").values
    df["hero_id"]    = metadata["hero_id"].fillna(0).astype(int).values
    df["lane_role"]  = metadata["lane_role"].fillna(0).astype(int).values
    df["win"]        = metadata.get("win", pd.Series([-1]*len(df))).values

    df["hero_name"] = df["hero_id"].map(lambda i: hero_lookup.get(int(i), f"Hero {int(i)}"))
    df["role_name"] = df["lane_role"].map(lambda r: ROLE_NAMES.get(int(r), "Unknown"))

    if cluster_labels is not None:
        df["cluster"] = [f"C{c}" for c in cluster_labels]

    return df


def _scatter(df, color_col, title, color_map=None, hover_cols=None):
    hover = hover_cols or ["hero_name", "role_name", "match_id"]
    kw = dict(
        data_frame=df, x="x", y="y", color=color_col,
        hover_data=hover,
        labels={"x": "UMAP 1", "y": "UMAP 2"},
        opacity=0.65,
        template="plotly_dark",
        title=title,
    )
    if color_map:
        kw["color_discrete_map"] = color_map
    fig = px.scatter(**kw)
    fig.update_traces(marker=dict(size=4))
    fig.update_layout(
        width=920, height=660,
        paper_bgcolor=_DARK_BG,
        plot_bgcolor="#161b22",
        title_font_size=16,
        legend=dict(itemsizing="constant", font_size=11),
    )
    return fig


# ---------------------------------------------------------------------------
# Individual plot builders
# ---------------------------------------------------------------------------

def plot_by_role(df):
    return _scatter(df, "role_name", "Embeddings — Lane Role", ROLE_COLORS)


def plot_by_hero(df, top_n: int = 20):
    top = df["hero_name"].value_counts().head(top_n).index
    d = df.copy()
    d["hero_display"] = d["hero_name"].where(d["hero_name"].isin(top), "Other")
    return _scatter(d, "hero_display",
                    f"Embeddings — Hero (top {top_n})",
                    hover_cols=["role_name", "match_id", "account_id"])


def plot_by_player(df, top_n: int = 15):
    top = df["account_id"].value_counts().head(top_n).index
    d = df.copy()
    d["player"] = d["account_id"].astype(str).where(d["account_id"].isin(top), "Other")
    return _scatter(d, "player",
                    f"Embeddings — Player (top {top_n})",
                    hover_cols=["hero_name", "role_name", "match_id"])


def plot_by_cluster(df):
    if "cluster" not in df.columns:
        raise ValueError("No cluster labels — run cluster_sweep first")
    return _scatter(df, "cluster",
                    "Embeddings — Cluster Assignment",
                    hover_cols=["hero_name", "role_name", "account_id"])


def plot_cluster_profiles(cluster_stats: Dict) -> go.Figure:
    """Stacked bar showing role composition per cluster, plus cluster sizes."""
    cids   = sorted(cluster_stats)
    labels = [f"C{c}" for c in cids]
    colors = list(ROLE_COLORS.values())

    fig = make_subplots(
        rows=1, cols=2,
        subplot_titles=("Cluster Size", "Role Distribution"),
        column_widths=[0.28, 0.72],
    )

    fig.add_trace(go.Bar(
        x=labels,
        y=[cluster_stats[c]["size"] for c in cids],
        marker_color="#3d84c6", name="n", showlegend=False,
    ), row=1, col=1)

    for i, (rid, rname) in enumerate(ROLE_NAMES.items()):
        fracs = []
        for c in cids:
            dist = cluster_stats[c].get("lane_role_dist", {})
            # Stratz returns role as string e.g. "SAFE_LANE" or int 1
            val = dist.get(rid) or dist.get(float(rid)) or dist.get(str(rid)) or 0.0
            fracs.append(val)
        fig.add_trace(go.Bar(
            x=labels, y=fracs, name=rname,
            marker_color=colors[i % len(colors)],
        ), row=1, col=2)

    fig.update_layout(
        barmode="stack", template="plotly_dark",
        paper_bgcolor=_DARK_BG,
        title="Cluster Profiles — Role Composition",
        width=1100, height=420,
        legend=dict(title="Role", font_size=11),
    )
    return fig


def plot_silhouette(scores: Dict[int, float]) -> go.Figure:
    ks = sorted(scores)
    best_k = max(scores, key=scores.get)
    colors = ["#e74c3c" if k == best_k else "#3d84c6" for k in ks]
    fig = go.Figure(go.Bar(
        x=[str(k) for k in ks],
        y=[scores[k] for k in ks],
        marker_color=colors,
        text=[f"{scores[k]:.3f}" for k in ks],
        textposition="outside",
    ))
    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor=_DARK_BG,
        title=f"KMeans Silhouette Scores — best k={best_k} (red)",
        xaxis_title="k (number of clusters)",
        yaxis_title="Silhouette Score",
        width=720, height=380,
    )
    return fig


# ---------------------------------------------------------------------------
# Dashboard builder
# ---------------------------------------------------------------------------

_STYLE = """
<style>
  body  { background: #0d1117; color: #e6edf3; font-family: -apple-system, sans-serif;
          padding: 32px; max-width: 1200px; margin: 0 auto; }
  h1    { text-align: center; font-size: 1.8rem; margin-bottom: 4px; }
  h2    { font-size: 1.15rem; margin: 32px 0 6px; color: #8b949e; border-bottom: 1px solid #21262d; padding-bottom: 6px; }
  .desc { max-width: 860px; margin: 0 auto 28px; text-align: center; color: #8b949e; font-size: 0.9rem; line-height: 1.6; }
  .note { font-size: 0.82rem; color: #484f58; margin-top: 4px; }
</style>
"""

_DESCRIPTION = """
<p class="desc">
  High-dimensional vectors of laning behaviour projected to 2D via UMAP.
  <br>
  Input features: farm trajectory, economic rates, combat, vision, healing, purchase timing, APM, and (where available) Clarity replay features.
  <br>
  <strong>Hero ID, player ID, and lane role are intentionally excluded from the feature vector.</strong>
  Any structure visible in the views below is emergent — not imposed.
</p>
"""


def create_dashboard(
    embedding: np.ndarray,
    metadata: pd.DataFrame,
    hero_lookup: Dict[int, str],
    cluster_labels: Optional[np.ndarray] = None,
    cluster_stats: Optional[Dict] = None,
    silhouette_scores: Optional[Dict] = None,
    output_path: str = "laning_dashboard.html",
) -> str:
    """
    Build a self-contained HTML dashboard and write it to output_path.
    Returns the output path.
    """
    df = _build_viz_df(embedding, metadata, hero_lookup, cluster_labels)

    parts = [
        "<!DOCTYPE html><html lang='en'><head>",
        "<meta charset='UTF-8'>",
        "<title>DOTA 2 Laning Embeddings</title>",
        _STYLE,
        "</head><body>",
        "<h1>DOTA 2 Laning Performance Embeddings</h1>",
        _DESCRIPTION,
    ]

    first = True
    def section(title, fig, note=""):
        nonlocal first
        parts.append(f"<h2>{title}</h2>")
        if note:
            parts.append(f"<p class='note'>{note}</p>")
        include_js = "cdn" if first else False
        parts.append(to_html(fig, full_html=False, include_plotlyjs=include_js))
        first = False

    section("Lane Role View",
            plot_by_role(df),
            "Validation: if role clusters appear here, the embedding captured role-defining behaviour without being told role labels.")

    section("Hero View",
            plot_by_hero(df),
            "Hero clustering indicates the embedding encodes hero-specific playstyle patterns.")

    section("Player View",
            plot_by_player(df),
            "Player clustering indicates individual style consistency across matches and heroes.")

    if cluster_labels is not None:
        section("Cluster View", plot_by_cluster(df))

    if cluster_stats:
        section("Cluster Profiles", plot_cluster_profiles(cluster_stats))

    if silhouette_scores:
        section("Silhouette Score Sweep", plot_silhouette(silhouette_scores))

    parts.append("</body></html>")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(parts))

    logger.info(f"Dashboard → {output_path}")
    return output_path
