"""
main.py — CLI entry point for DOTA 2 Laning Embeddings

Typical usage
-------------
# Stratz only (recommended starting point):
python main.py --api-key YOUR_STRATZ_KEY \\
               --steam-ids 76561198012345678 76561198087654321 \\
               --matches-per-player 50

# Stratz + Clarity replays (richest feature set):
python main.py --api-key YOUR_STRATZ_KEY \\
               --steam-ids 76561198012345678 \\
               --clarity-dir ./replays/parsed/ \\
               --clarity-parser clarity

# Load from existing Stratz cache (no API calls):
python main.py --stratz-cache ./stratz_cache \\
               --load-cache-only

# Tune UMAP:
python main.py --api-key KEY --steam-ids ID \\
               --n-neighbors 25 --min-dist 0.05 --pca 20

# Disable clustering (faster iteration):
python main.py --api-key KEY --steam-ids ID --no-cluster

Notes
-----
- Stratz uses Steam64 IDs (17-digit).
  Convert from OpenDota 32-bit: steam64 = account_id + 76561197960265728
- Free Stratz tier: 500 req/hour. The client defaults to 7.5s between requests.
- Clarity parser options: "clarity" (skadistats) | "manta" (dotabuff)
  See fetch_clarity.py and docs/clarity_setup.md for parser details.
"""

import argparse
import logging
import json
import numpy as np
from pathlib import Path

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(message)s",
    datefmt="%H:%M:%S",
)
logger = logging.getLogger(__name__)


def parse_args():
    p = argparse.ArgumentParser(description="DOTA 2 Laning Embeddings Pipeline")

    # ── Data sources ──────────────────────────────────────────────────────────
    p.add_argument("--api-key",             type=str,   default=None,
                   help="Stratz API bearer token (https://stratz.com/api)")
    p.add_argument("--steam-ids",           nargs="+",  type=int,
                   help="Steam64 account IDs to fetch matches for")
    p.add_argument("--matches-per-player",  type=int,   default=40)
    p.add_argument("--stratz-cache",        type=str,   default="stratz_cache",
                   help="Directory for cached Stratz match JSON files")
    p.add_argument("--load-cache-only",     action="store_true",
                   help="Skip API calls and build dataset from existing cache directory")

    p.add_argument("--clarity-dir",         type=str,   default=None,
                   help="Directory of Clarity-parsed replay files (.json/.parquet/.csv)")
    p.add_argument("--clarity-parser",      type=str,   default="clarity",
                   choices=["clarity", "manta"],
                   help="Parser that produced the Clarity files (default: clarity)")

    # ── Pipeline ──────────────────────────────────────────────────────────────
    p.add_argument("--n-neighbors",  type=int,   default=15,
                   help="UMAP n_neighbors (higher = more global structure)")
    p.add_argument("--min-dist",     type=float, default=0.1,
                   help="UMAP min_dist (lower = tighter clusters)")
    p.add_argument("--pca",          type=int,   default=None,
                   help="Pre-UMAP PCA components (recommended: 20 for n>2000)")

    # ── Clustering ────────────────────────────────────────────────────────────
    p.add_argument("--no-cluster",   action="store_true")
    p.add_argument("--k-min",        type=int,   default=4)
    p.add_argument("--k-max",        type=int,   default=14)

    # ── Output ────────────────────────────────────────────────────────────────
    p.add_argument("--output",       type=str,   default="laning_dashboard.html")

    return p.parse_args()


def load_cache_as_matches(cache_dir: str):
    """Load all cached Stratz match JSON files from a directory."""
    cache = Path(cache_dir)
    files = sorted(cache.glob("*.json"))
    logger.info(f"Loading {len(files)} cached matches from {cache_dir}")
    matches = []
    for f in files:
        try:
            data = json.loads(f.read_text())
            if data.get("players"):
                matches.append(data)
        except Exception as e:
            logger.warning(f"Skipping {f.name}: {e}")
    logger.info(f"Loaded {len(matches)} valid cached matches")
    return matches


def main():
    args = parse_args()

    # ── 1. Load match data ────────────────────────────────────────────────────
    matches = []

    if args.load_cache_only:
        matches = load_cache_as_matches(args.stratz_cache)

    elif args.api_key and args.steam_ids:
        from fetch_stratz import StratzClient
        client = StratzClient(api_key=args.api_key)
        matches = client.fetch_matches_for_players(
            args.steam_ids,
            matches_per_player=args.matches_per_player,
            cache_dir=args.stratz_cache,
        )

    else:
        raise SystemExit(
            "Provide either:\n"
            "  --api-key + --steam-ids     (fetch from Stratz)\n"
            "  --load-cache-only           (use existing stratz_cache/)\n"
        )

    if not matches:
        raise SystemExit("No match data loaded.")

    # ── 2. Optional Clarity augmentation ─────────────────────────────────────
    clarity_index = None
    if args.clarity_dir:
        from fetch_clarity import load_clarity_directory, build_clarity_feature_index
        clarity_matches = load_clarity_directory(args.clarity_dir, parser=args.clarity_parser)
        clarity_index   = build_clarity_feature_index(clarity_matches, parser=args.clarity_parser)
        logger.info(f"Clarity augmentation: {len(clarity_index)} records")

    # ── 3. Feature engineering ────────────────────────────────────────────────
    from feature_engineering import build_dataset
    features_df, metadata_df = build_dataset(matches, clarity_index=clarity_index)

    if len(features_df) < 20:
        raise SystemExit(f"Only {len(features_df)} records — need ≥ 20.")

    features_df.to_csv("laning_features.csv", index=False)
    metadata_df.to_csv("laning_metadata.csv",  index=False)
    logger.info(f"Saved CSVs: {len(features_df)} × {len(features_df.columns)} features")

    # ── 4. Embedding pipeline ─────────────────────────────────────────────────
    from pipeline import LaningEmbeddingPipeline
    pipe = LaningEmbeddingPipeline(
        n_neighbors=args.n_neighbors,
        min_dist=args.min_dist,
        pca_components=args.pca,
    )
    X_scaled, embedding = pipe.fit_transform(features_df)

    np.save("laning_vectors_highd.npy", X_scaled)
    np.save("laning_vectors_2d.npy",    embedding)
    pipe.save("laning_pipeline.joblib")

    # ── 5. Clustering ─────────────────────────────────────────────────────────
    cluster_labels = cluster_stats = silhouette_scores = None
    if not args.no_cluster:
        from pipeline import cluster_sweep
        k_max = min(args.k_max, len(features_df) // 10)
        if k_max >= args.k_min:
            cluster_labels, cluster_stats, silhouette_scores = cluster_sweep(
                X_scaled, metadata_df, k_min=args.k_min, k_max=k_max
            )
            for cid, stats in cluster_stats.items():
                logger.info(f"  C{cid}: n={stats['size']}  roles={stats['lane_role_dist']}")

    # ── 6. Dashboard ──────────────────────────────────────────────────────────
    from visualize import create_dashboard
    hero_lookup = {int(i): f"Hero {int(i)}"
                   for i in metadata_df["hero_id"].dropna().unique()}

    # If you have a hero name lookup from Stratz, load it here:
    # hero_lookup = json.loads(Path("hero_names.json").read_text())

    create_dashboard(
        embedding=embedding,
        metadata=metadata_df,
        hero_lookup=hero_lookup,
        cluster_labels=cluster_labels,
        cluster_stats=cluster_stats,
        silhouette_scores=silhouette_scores,
        output_path=args.output,
    )

    logger.info("=" * 55)
    logger.info(f"  Dashboard  → {args.output}")
    logger.info(f"  HD vectors → laning_vectors_highd.npy  {X_scaled.shape}")
    logger.info(f"  2D embed   → laning_vectors_2d.npy      {embedding.shape}")
    logger.info(f"  Pipeline   → laning_pipeline.joblib")
    logger.info("=" * 55)


if __name__ == "__main__":
    main()
