"""
fetch_stratz.py
---------------
Stratz GraphQL API client with rate limiting and file caching.

Get a free API key at: https://stratz.com/api
Free tier: 500 requests/hour.

NOTE: Stratz uses Steam64 IDs (17-digit), NOT OpenDota 32-bit account IDs.
Convert: steam64 = opendota_account_id + 76561197960265728
"""

import requests
import time
import json
import logging
from pathlib import Path
from typing import Optional, List, Dict

logger = logging.getLogger(__name__)

STRATZ_ENDPOINT = "https://api.stratz.com/graphql"
LANING_MIN = 10

# ---------------------------------------------------------------------------
# GraphQL Queries
# ---------------------------------------------------------------------------

LANING_QUERY = """
query GetMatch($matchId: Long!) {
  match(id: $matchId) {
    id
    didRadiantWin
    durationSeconds
    players {
      steamAccountId
      heroId
      playerSlot
      lane
      laneRole
      isRandom
      kills
      deaths
      assists
      goldPerMinute
      experiencePerMinute
      heroDamage
      towerDamage
      heroHealing
      numLastHits
      numDenies
      imp

      stats {
        goldPerMinute
        experiencePerMinute
        networthPerMinute
        lastHitPerMinute
        deniesPerMinute
        heroDamagePerMinute
        towerDamagePerMinute
        actionsPerMinute

        wardDestinationEvents {
          time
          positionX
          positionY
          type
        }
        killEvents  { time }
        deathEvents { time }
        assistEvents { time }
      }

      playbackData {
        abilityActivationEvents {
          time
          abilityId
          isUltimate
        }
        itemPurchaseEvents {
          time
          itemId
        }
      }
    }
  }
}
"""

PLAYER_MATCHES_QUERY = """
query GetPlayerMatches($steamAccountId: Long!, $take: Int!) {
  player(steamAccountId: $steamAccountId) {
    matches(request: { take: $take, isParsed: true }) {
      id
    }
  }
}
"""


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class StratzClient:
    """
    Rate-limited Stratz GraphQL API client.

    Args:
        api_key:       Bearer token from https://stratz.com/api
        request_delay: Seconds between requests.
                       Default 7.5s → ~480 req/hr (under 500 free-tier limit).
                       Set to 1.5s if you have a paid plan.
    """

    def __init__(self, api_key: str, request_delay: float = 7.5):
        if not api_key:
            raise ValueError(
                "Stratz requires an API key. Get one free at https://stratz.com/api"
            )
        self.api_key = api_key
        self.request_delay = request_delay
        self._last_request = 0.0

        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "dota-laning-embeddings/1.0",
        })

    # ------------------------------------------------------------------
    # Internal
    # ------------------------------------------------------------------

    def _gql(self, query: str, variables: dict) -> Optional[dict]:
        elapsed = time.time() - self._last_request
        if elapsed < self.request_delay:
            time.sleep(self.request_delay - elapsed)

        try:
            r = self.session.post(
                STRATZ_ENDPOINT,
                json={"query": query, "variables": variables},
                timeout=30,
            )
            self._last_request = time.time()

            if r.status_code == 429:
                retry = int(r.headers.get("Retry-After", 60))
                logger.warning(f"Rate limited — sleeping {retry}s")
                time.sleep(retry)
                return self._gql(query, variables)

            r.raise_for_status()
            data = r.json()

            if "errors" in data:
                logger.error(f"GraphQL errors: {data['errors']}")
                return None

            return data.get("data")

        except requests.RequestException as e:
            logger.error(f"Stratz request failed: {e}")
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def get_player_match_ids(self, steam_account_id: int, limit: int = 50) -> List[int]:
        """Return the most recent `limit` parsed match IDs for a player."""
        data = self._gql(PLAYER_MATCHES_QUERY, {
            "steamAccountId": steam_account_id,
            "take": limit,
        })
        if not data:
            return []
        matches = (data.get("player") or {}).get("matches") or []
        return [m["id"] for m in matches]

    def get_match(self, match_id: int) -> Optional[dict]:
        """Fetch full laning data for a single match."""
        data = self._gql(LANING_QUERY, {"matchId": match_id})
        return data.get("match") if data else None

    def fetch_matches_for_players(
        self,
        steam_account_ids: List[int],
        matches_per_player: int = 40,
        cache_dir: str = "stratz_cache",
    ) -> List[dict]:
        """
        Fetch parsed match data for a list of Steam64 account IDs.

        Each match is cached as {match_id}.json inside `cache_dir` so
        re-runs skip already-fetched matches.
        """
        cache = Path(cache_dir)
        cache.mkdir(exist_ok=True)

        all_ids: set = set()
        for sid in steam_account_ids:
            logger.info(f"Fetching match list for Steam ID {sid}")
            ids = self.get_player_match_ids(sid, limit=matches_per_player)
            all_ids.update(ids)
            logger.info(f"  → {len(ids)} matches")

        logger.info(f"Total unique matches: {len(all_ids)}")

        results = []
        for i, mid in enumerate(sorted(all_ids)):
            cf = cache / f"{mid}.json"
            match_data = None

            if cf.exists():
                try:
                    match_data = json.loads(cf.read_text())
                    logger.debug(f"Cache hit: {mid}")
                except json.JSONDecodeError:
                    logger.warning(f"Corrupt cache for {mid}, re-fetching")

            if match_data is None:
                logger.info(f"[{i+1}/{len(all_ids)}] Fetching match {mid}")
                match_data = self.get_match(mid)
                if match_data:
                    cf.write_text(json.dumps(match_data))
                else:
                    logger.warning(f"  Failed to fetch match {mid}")
                    continue

            if match_data and match_data.get("players"):
                results.append(match_data)

        logger.info(f"Collected {len(results)} valid matches")
        return results
