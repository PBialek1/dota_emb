/**
 * ClarityExtractor.java
 * ---------------------
 * Reference extractor for Dota 2 replays using skadistats/clarity.
 *
 * Extracts per-player laning data to JSON:
 *   - Position ticks (every 2 seconds)
 *   - Ability cast events
 *   - Attack and move commands
 *   - Rune pickup events
 *
 * Compile:
 *   javac -cp clarity-2.x.jar ClarityExtractor.java
 *
 * Run (single replay):
 *   java -cp .:clarity-2.x.jar ClarityExtractor replay.dem output/
 *
 * Run (batch):
 *   for f in replays/*.dem; do
 *     java -cp .:clarity-2.x.jar ClarityExtractor "$f" output/
 *   done
 *
 * Download clarity JAR from:
 *   https://github.com/skadistats/clarity/releases
 *
 * This is a template — adapt event names to the clarity version you are using.
 * The skadistats/clarity wiki has full event/entity documentation.
 */

import skadistats.clarity.processor.runner.SimpleRunner;
import skadistats.clarity.model.Entity;
import skadistats.clarity.model.FieldPath;
import skadistats.clarity.event.Provides;
import skadistats.clarity.processor.entities.OnEntityCreated;
import skadistats.clarity.processor.entities.OnEntityUpdated;
import skadistats.clarity.processor.gameevents.OnCombatLogEntry;
import skadistats.clarity.processor.runner.Context;
import skadistats.clarity.wire.common.proto.Demo.CDemoFileInfo;

import java.io.*;
import java.util.*;
import org.json.JSONObject;
import org.json.JSONArray;

public class ClarityExtractor {

    // Position sampling interval in game ticks (30 ticks/sec → 60 = every 2s)
    private static final int POSITION_SAMPLE_TICKS = 60;
    private static final int LANING_TICKS = 10 * 60 * 30;  // 10 minutes

    // Per-player data collectors
    private final Map<Integer, List<JSONObject>> positionTicks    = new HashMap<>();
    private final Map<Integer, List<JSONObject>> abilityCasts     = new HashMap<>();
    private final Map<Integer, List<JSONObject>> attackCommands   = new HashMap<>();
    private final Map<Integer, List<JSONObject>> moveCommands     = new HashMap<>();
    private final Map<Integer, List<JSONObject>> runeEvents       = new HashMap<>();
    private final Map<Integer, Integer>          heroIds          = new HashMap<>();
    private final Map<Integer, String>           steamIds         = new HashMap<>();

    private long matchId = -1;
    private int  durationSeconds = 0;

    // ------------------------------------------------------------------
    // Entity tracking: hero positions (sampled every POSITION_SAMPLE_TICKS)
    // ------------------------------------------------------------------
    @OnEntityUpdated
    public void onEntityUpdated(Context ctx, Entity e, FieldPath[] fieldPaths, int updateCount) {
        if (!e.getDtClass().getDtName().startsWith("CDOTA_Unit_Hero_")) return;

        int tick = ctx.getTick();
        if (tick > LANING_TICKS) return;
        if (tick % POSITION_SAMPLE_TICKS != 0) return;

        int slot  = getPlayerSlot(e);
        float[] xy = getPosition(e);
        if (slot < 0 || xy == null) return;

        JSONObject pt = new JSONObject();
        pt.put("time",  tickToSeconds(tick));
        pt.put("x",     (int) xy[0]);
        pt.put("y",     (int) xy[1]);
        positionTicks.computeIfAbsent(slot, k -> new ArrayList<>()).add(pt);
    }

    // ------------------------------------------------------------------
    // Combat log: ability casts, attacks, deaths, kills
    // ------------------------------------------------------------------
    @OnCombatLogEntry
    public void onCombatLog(Context ctx, CombatLogEntry cle) {
        int tick = ctx.getTick();
        if (tick > LANING_TICKS) return;

        int timeSeconds = tickToSeconds(tick);
        int slot = getSlotFromName(cle.getAttackerName());
        if (slot < 0) return;

        switch (cle.getType()) {
            case DOTA_COMBATLOG_ABILITY:
                JSONObject cast = new JSONObject();
                cast.put("time", timeSeconds);
                cast.put("ability", cle.getInflictorName());
                cast.put("is_ult", cle.isAbilityIsUltimate());
                abilityCasts.computeIfAbsent(slot, k -> new ArrayList<>()).add(cast);
                break;

            case DOTA_COMBATLOG_ATTACK:
                JSONObject atk = new JSONObject();
                atk.put("time", timeSeconds);
                atk.put("target_type", cle.getTargetName().contains("creep") ? "creep" : "hero");
                attackCommands.computeIfAbsent(slot, k -> new ArrayList<>()).add(atk);
                break;

            default:
                break;
        }
    }

    // ------------------------------------------------------------------
    // Rune pickups
    // ------------------------------------------------------------------
    @OnEntityCreated
    public void onEntityCreated(Context ctx, Entity e) {
        // Rune pickup entities appear transiently; capture creation as pickup event
        if (!e.getDtClass().getDtName().equals("CDOTARuneSpawner_Bounty")) return;
        int tick = ctx.getTick();
        if (tick > LANING_TICKS) return;

        // Associate with nearest hero — simplified; full impl uses position lookup
        // This is left as an exercise; the feature code handles missing rune_events gracefully
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------
    private int tickToSeconds(int tick) {
        return tick / 30;
    }

    private int getPlayerSlot(Entity e) {
        try { return (int) e.getProperty("m_iPlayerID"); }
        catch (Exception ex) { return -1; }
    }

    private float[] getPosition(Entity e) {
        try {
            float x = (float) e.getProperty("CBodyComponentBaseAnimatingOverlay.m_cellX");
            float y = (float) e.getProperty("CBodyComponentBaseAnimatingOverlay.m_cellY");
            return new float[]{x, y};
        } catch (Exception ex) { return null; }
    }

    private int getSlotFromName(String name) {
        // Map hero internal name to player slot — implement using entity lookup
        return -1; // placeholder
    }

    // ------------------------------------------------------------------
    // Output
    // ------------------------------------------------------------------
    public JSONObject toJson() {
        JSONObject out = new JSONObject();
        out.put("match_id",          matchId);
        out.put("duration_seconds",  durationSeconds);

        JSONArray players = new JSONArray();
        for (int slot = 0; slot < 10; slot++) {
            JSONObject p = new JSONObject();
            p.put("player_slot",     slot);
            p.put("hero_id",         heroIds.getOrDefault(slot, 0));
            p.put("steam_id",        steamIds.getOrDefault(slot, ""));
            p.put("position_ticks",  new JSONArray(positionTicks.getOrDefault(slot, List.of())));
            p.put("ability_casts",   new JSONArray(abilityCasts.getOrDefault(slot, List.of())));
            p.put("attack_commands", new JSONArray(attackCommands.getOrDefault(slot, List.of())));
            p.put("move_commands",   new JSONArray(moveCommands.getOrDefault(slot, List.of())));
            p.put("rune_events",     new JSONArray(runeEvents.getOrDefault(slot, List.of())));
            players.put(p);
        }
        out.put("players", players);
        return out;
    }

    // ------------------------------------------------------------------
    // Entry point
    // ------------------------------------------------------------------
    public static void main(String[] args) throws Exception {
        if (args.length < 2) {
            System.err.println("Usage: ClarityExtractor <replay.dem> <output_dir/>");
            System.exit(1);
        }

        String replayPath = args[0];
        File outputDir    = new File(args[1]);
        outputDir.mkdirs();

        ClarityExtractor extractor = new ClarityExtractor();
        new SimpleRunner(new MappedFileSource(replayPath)).runWith(extractor);

        // Derive match ID from filename if not found in replay
        if (extractor.matchId < 0) {
            String fname = new File(replayPath).getName().replaceAll("[^0-9]", "");
            if (!fname.isEmpty()) extractor.matchId = Long.parseLong(fname);
        }

        File outputFile = new File(outputDir, extractor.matchId + ".json");
        try (FileWriter fw = new FileWriter(outputFile)) {
            extractor.toJson().write(fw, 2, 0);
        }

        System.out.println("Written: " + outputFile.getAbsolutePath());
    }
}
