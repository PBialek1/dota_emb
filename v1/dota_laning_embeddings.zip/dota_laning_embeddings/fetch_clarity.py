"""
fetch_clarity.py
----------------
Flexible loader for Dota 2 replay data parsed by Clarity (or compatible parsers).

Supported input formats
-----------------------
1. skadistats/clarity  → JSON, field names match this module's defaults
2. dotabuff/manta      → JSON, slightly different field names → use MANTA_FIELD_MAP
3. Custom pipeline     → Parquet or CSV per match → use load_clarity_parquet() / load_clarity_csv()
4. Flat directory of   → auto-detected by extension (.json / .parquet / .csv)
   any of the above

Clarity setup
-------------
See docs/clarity_setup.md for instructions on extracting replays to JSON.

Expected JSON schema (skadistats/clarity default)
-------------------------------------------------
{
  "match_id": 7654321,
  "duration_seconds": 2400,
  "players": [
    {
      "player_slot": 0,
      "hero_id": 1,
      "steam_id": "76561198012345678",
      "position_ticks": [          // sampled every ~2 seconds
        {"time": 0,   "x": 7120, "y": 7520},
        ...
      ],
      "ability_casts": [
        {"time": 45, "ability": "axe_berserkers_call", "is_ult": false},
        ...
      ],
      "attack_commands":  [{"time": 30, "target_type": "creep"}, ...],
      "move_commands":    [{"time": 31}, ...],
      "rune_events":      [{"time": 120, "rune_type": "bounty", "picked_up": true}, ...]
    }
  ]
}
"""

import json
import logging
import numpy as np
import pandas as pd
from pathlib import Path
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

LANING_SECONDS = 10 * 60

# ---------------------------------------------------------------------------
# Field name adapters for different parsers
# ---------------------------------------------------------------------------

# Each adapter maps (canonical_name → parser_specific_name) for player-level fields.
# Extend this dict to support additional parsers without touching feature code.

PARSER_FIELD_MAPS = {
    "clarity": {   # skadistats/clarity — default, no remapping needed
        "player_slot":      "player_slot",
        "hero_id":          "hero_id",
        "steam_id":         "steam_id",
        "position_ticks":   "position_ticks",
        "ability_casts":    "ability_casts",
        "attack_commands":  "attack_commands",
        "move_commands":    "move_commands",
        "rune_events":      "rune_events",
    },
    "manta": {     # dotabuff/manta — renames a few fields
        "player_slot":      "slot",
        "hero_id":          "hero",
        "steam_id":         "steamid",
        "position_ticks":   "positions",
        "ability_casts":    "spells",
        "attack_commands":  "attacks",
        "move_commands":    "moves",
        "rune_events":      "runes",
    },
}


def _normalize_player(raw: dict, parser: str = "clarity") -> dict:
    """Remap field names from parser-specific to canonical names."""
    fmap = PARSER_FIELD_MAPS.get(parser, PARSER_FIELD_MAPS["clarity"])
    out = {}
    for canonical, parser_key in fmap.items():
        out[canonical] = raw.get(parser_key) or raw.get(canonical)
    return out


# ---------------------------------------------------------------------------
# Lane geometry helpers
# ---------------------------------------------------------------------------

# Approximate lane spine coordinates (Dota map units).
# Used to compute lane deviation — how far a player drifts from their lane.
LANE_PATHS = {
    "top": ((4000, 10000), (10000, 13000)),
    "mid": ((5000,  5000), (10000, 10000)),
    "bot": ((10000, 4000), (13000, 10000)),
}

# Bounding boxes (x_min, y_min, x_max, y_max) considered "jungle"
JUNGLE_BBOX = [
    (5000, 5800,  8000, 8000),    # Radiant jungle
    (8200, 8500, 11500, 12000),   # Dire jungle
]


def _seg_dist(px, py, ax, ay, bx, by) -> float:
    """Distance from point P to line segment AB."""
    dx, dy = bx - ax, by - ay
    if dx == dy == 0:
        return float(np.hypot(px - ax, py - ay))
    t = max(0.0, min(1.0, ((px - ax)*dx + (py - ay)*dy) / (dx*dx + dy*dy)))
    return float(np.hypot(px - (ax + t*dx), py - (ay + t*dy)))


def _in_jungle(x, y) -> bool:
    return any(x0 <= x <= x1 and y0 <= y <= y1 for x0, y0, x1, y1 in JUNGLE_BBOX)


def _movement_entropy(positions: List[Tuple[float, float]], grid_size: int = 512) -> float:
    """
    Shannon entropy of grid cells visited.
    High → roamer/rotator. Low → static laner/farmer.
    """
    if len(positions) < 2:
        return 0.0
    cells: Dict[Tuple[int, int], int] = {}
    for x, y in positions:
        k = (int(x // grid_size), int(y // grid_size))
        cells[k] = cells.get(k, 0) + 1
    total = sum(cells.values())
    return float(-sum((v/total) * np.log2(v/total + 1e-12) for v in cells.values()))


# ---------------------------------------------------------------------------
# Per-player feature extractor
# ---------------------------------------------------------------------------

def extract_clarity_features(player_raw: dict, parser: str = "clarity") -> Optional[Dict]:
    """
    Extract positioning and behavioural features from Clarity replay data.

    These features are unavailable from any API and only exist in replay data:
      - Lane deviation      (how far from lane path spine)
      - Jungle fraction     (fraction of ticks spent in jungle)
      - Movement entropy    (spread of positions → roamer vs static)
      - Forward positioning (aggression proxy via fountain distance)
      - Ability cast counts, timing, and rhythm
      - Attack/move command ratio (mechanics proxy)
      - Early rune activity

    Returns a flat dict of features to merge into the base feature vector,
    or None if there is insufficient positional data.
    """
    p = _normalize_player(player_raw, parser)

    ticks = p.get("position_ticks") or []
    lane_ticks = [t for t in ticks if t.get("time", 1e9) <= LANING_SECONDS]
    if len(lane_ticks) < 5:
        return None

    positions = [(t["x"], t["y"]) for t in lane_ticks]
    xs, ys = zip(*positions)

    # -- Lane deviation -------------------------------------------------------
    min_lane_deviation = min(
        float(np.mean([_seg_dist(x, y, ax, ay, bx, by) for x, y in positions]))
        for (ax, ay), (bx, by) in LANE_PATHS.values()
    )

    # -- Jungle fraction ------------------------------------------------------
    jungle_fraction = sum(1 for x, y in positions if _in_jungle(x, y)) / len(positions)

    # -- Movement entropy -----------------------------------------------------
    move_entropy = _movement_entropy(positions)

    # -- Forward positioning (distance from Radiant fountain as aggression proxy)
    mean_dist_from_fountain = float(np.mean([np.hypot(x - 128, y - 128) for x, y in positions]))

    # -- Position variance (stability)
    pos_variance = float(np.var(xs) + np.var(ys))

    # -- Ability casts --------------------------------------------------------
    casts = p.get("ability_casts") or []
    lane_casts = [c for c in casts if c.get("time", 1e9) <= LANING_SECONDS]
    total_casts_10 = len(lane_casts)
    ult_casts_10   = sum(1 for c in lane_casts if c.get("is_ult"))
    spell_casts_10 = total_casts_10 - ult_casts_10

    offense_times = sorted(
        c["time"] for c in lane_casts
        if not c.get("is_ult") and c.get("time") is not None
    )
    first_cast_time = offense_times[0] if offense_times else LANING_SECONDS

    if len(offense_times) >= 2:
        ivls = [offense_times[i+1] - offense_times[i] for i in range(len(offense_times)-1)]
        cast_interval_mean = float(np.mean(ivls))
        cast_interval_std  = float(np.std(ivls))
    else:
        cast_interval_mean = cast_interval_std = 0.0

    # -- Attack/move ratio ----------------------------------------------------
    attacks = p.get("attack_commands") or []
    moves   = p.get("move_commands")   or []
    lane_atk = sum(1 for a in attacks if a.get("time", 1e9) <= LANING_SECONDS)
    lane_mov = sum(1 for m in moves   if m.get("time", 1e9) <= LANING_SECONDS)
    attack_move_ratio = lane_atk / max(1, lane_atk + lane_mov)

    # -- Rune activity --------------------------------------------------------
    runes = p.get("rune_events") or []
    early_runes = sum(1 for r in runes if r.get("time", 1e9) <= 180)
    rune_pickup_rate = early_runes / max(1, len(runes)) if runes else 0.0

    return dict(
        lane_deviation=min_lane_deviation,
        jungle_fraction=jungle_fraction,
        move_entropy=move_entropy,
        mean_dist_from_fountain=mean_dist_from_fountain,
        pos_variance=pos_variance,
        total_casts_10=total_casts_10,
        ult_casts_10=ult_casts_10,
        spell_casts_10=spell_casts_10,
        first_cast_time=first_cast_time,
        cast_interval_mean=cast_interval_mean,
        cast_interval_std=cast_interval_std,
        attack_move_ratio=attack_move_ratio,
        early_rune_activity=early_runes,
        rune_pickup_rate=rune_pickup_rate,
    )


# ---------------------------------------------------------------------------
# Loaders — auto-detect format or load explicitly
# ---------------------------------------------------------------------------

def load_clarity_json(filepath: str) -> Optional[Dict]:
    try:
        return json.loads(Path(filepath).read_text())
    except Exception as e:
        logger.error(f"Failed to load JSON {filepath}: {e}")
        return None


def load_clarity_parquet(filepath: str) -> Optional[Dict]:
    """
    Load a Parquet file where each row is one player-tick or one player-event.

    Expected columns (player-level aggregated Parquet):
      match_id, player_slot, hero_id, steam_id,
      time, pos_x, pos_y,              ← positional ticks (one row per tick)
      ability_name, is_ult,            ← ability casts
      event_type                       ← 'position' | 'ability' | 'attack' | 'move' | 'rune'

    This function reconstructs the nested JSON schema expected by
    extract_clarity_features() from the flat table.
    """
    try:
        df = pd.read_parquet(filepath)
    except Exception as e:
        logger.error(f"Failed to load Parquet {filepath}: {e}")
        return None

    if df.empty:
        return None

    match_id = int(df["match_id"].iloc[0]) if "match_id" in df.columns else -1
    players = []

    for slot, grp in df.groupby("player_slot"):
        def events(etype):
            sub = grp[grp["event_type"] == etype] if "event_type" in grp.columns else pd.DataFrame()
            return sub.to_dict("records")

        pos_rows = events("position")
        position_ticks = [{"time": r.get("time", 0), "x": r.get("pos_x", 0), "y": r.get("pos_y", 0)}
                          for r in pos_rows]

        ab_rows = events("ability")
        ability_casts = [{"time": r.get("time", 0),
                          "ability": r.get("ability_name", ""),
                          "is_ult": bool(r.get("is_ult", False))}
                         for r in ab_rows]

        players.append({
            "player_slot":    int(slot),
            "hero_id":        int(grp["hero_id"].iloc[0]) if "hero_id" in grp.columns else 0,
            "steam_id":       str(grp["steam_id"].iloc[0]) if "steam_id" in grp.columns else "",
            "position_ticks": position_ticks,
            "ability_casts":  ability_casts,
            "attack_commands":[{"time": r.get("time", 0)} for r in events("attack")],
            "move_commands":  [{"time": r.get("time", 0)} for r in events("move")],
            "rune_events":    [{"time": r.get("time", 0), "picked_up": True}
                               for r in events("rune")],
        })

    return {"match_id": match_id, "players": players}


def load_clarity_csv(filepath: str) -> Optional[Dict]:
    """Same as load_clarity_parquet but reads a CSV."""
    try:
        df = pd.read_csv(filepath)
        # Temporarily save as parquet buffer to reuse logic (avoids duplication)
        import io, tempfile, os
        tmp = tempfile.NamedTemporaryFile(suffix=".parquet", delete=False)
        df.to_parquet(tmp.name, index=False)
        result = load_clarity_parquet(tmp.name)
        os.unlink(tmp.name)
        return result
    except Exception as e:
        logger.error(f"Failed to load CSV {filepath}: {e}")
        return None


def load_clarity_file(filepath: str, parser: str = "clarity") -> Optional[Dict]:
    """Auto-detect file format and load."""
    p = Path(filepath)
    if p.suffix == ".json":
        return load_clarity_json(filepath)
    elif p.suffix == ".parquet":
        return load_clarity_parquet(filepath)
    elif p.suffix == ".csv":
        return load_clarity_csv(filepath)
    else:
        logger.warning(f"Unknown extension {p.suffix} for {filepath}, trying JSON")
        return load_clarity_json(filepath)


def load_clarity_directory(directory: str, parser: str = "clarity") -> List[Dict]:
    """
    Load all match files from a directory.
    Supports mixed .json / .parquet / .csv files in the same directory.
    """
    path = Path(directory)
    files = sorted(
        f for f in path.iterdir()
        if f.suffix in (".json", ".parquet", ".csv")
    )
    logger.info(f"Loading {len(files)} Clarity files from {directory} (parser={parser})")

    matches = []
    for f in files:
        m = load_clarity_file(str(f), parser=parser)
        if m and m.get("players"):
            matches.append(m)

    logger.info(f"Loaded {len(matches)} valid Clarity matches")
    return matches


def build_clarity_feature_index(
    matches: List[Dict],
    parser: str = "clarity",
) -> Dict[Tuple[int, int], Dict]:
    """
    Pre-process Clarity matches into a fast lookup dict:
      {(match_id, player_slot): clarity_features_dict}

    Pass this to feature_engineering.build_dataset() as `clarity_index`.
    """
    index: Dict[Tuple[int, int], Dict] = {}
    for match in matches:
        mid = match.get("match_id")
        for p in match.get("players", []):
            slot = p.get("player_slot")
            feats = extract_clarity_features(p, parser=parser)
            if feats is not None and mid is not None and slot is not None:
                index[(int(mid), int(slot))] = feats

    logger.info(f"Clarity index: {len(index)} player-match records")
    return index
