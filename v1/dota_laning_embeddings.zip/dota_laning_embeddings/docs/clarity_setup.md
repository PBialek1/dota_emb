# Clarity Replay Parser Setup

Clarity (https://github.com/skadistats/clarity) is a Java library for parsing
Dota 2 .dem replay files. This pipeline supports three Clarity-compatible parsers.

---

## Option A — skadistats/clarity (Java, most complete)

### 1. Download replays
From a Stratz match page → "Download Replay", or via Valve's CDR:
```
curl "http://replay{cluster}.valve.net/570/{match_id}_{salt}.dem.bz2" -o match.dem.bz2
bzip2 -d match.dem.bz2
```
The cluster and salt values come from the Stratz match API response.

### 2. Run the extractor
A reference extractor is provided in `tools/ClarityExtractor.java`.
```bash
# Compile (requires clarity JAR from the releases page)
javac -cp clarity-2.x.jar tools/ClarityExtractor.java

# Extract one replay
java -cp .:clarity-2.x.jar ClarityExtractor match.dem output/

# Batch
for dem in replays/*.dem; do
  java -cp .:clarity-2.x.jar ClarityExtractor "$dem" output/
done
```
Output: one `{match_id}.json` per replay in the output directory.

### 3. Point the pipeline at the output
```bash
python main.py --api-key KEY --steam-ids ... --clarity-dir output/
```
Use `--clarity-parser clarity` (default).

---

## Option B — dotabuff/manta (Go, faster)

https://github.com/dotabuff/manta

Manta uses slightly different field names. Pass `--clarity-parser manta` and the
field name adapter in `fetch_clarity.py` handles the remapping automatically.

---

## Option C — Custom Parquet/CSV pipeline

If you have a custom extraction pipeline that outputs flat Parquet or CSV files,
`fetch_clarity.py` will load them automatically when the files have `.parquet` or
`.csv` extensions. See the `load_clarity_parquet()` docstring for the expected
column schema.

---

## Expected JSON output schema (skadistats/clarity)

```json
{
  "match_id": 7654321,
  "duration_seconds": 2400,
  "players": [
    {
      "player_slot": 0,
      "hero_id": 1,
      "steam_id": "76561198012345678",
      "position_ticks": [
        {"time": 0,   "x": 7120, "y": 7520},
        {"time": 2,   "x": 7124, "y": 7532}
      ],
      "ability_casts": [
        {"time": 45, "ability": "axe_berserkers_call", "is_ult": false}
      ],
      "attack_commands": [
        {"time": 30, "target_type": "creep"}
      ],
      "move_commands": [
        {"time": 31}
      ],
      "rune_events": [
        {"time": 120, "rune_type": "bounty", "picked_up": true}
      ]
    }
  ]
}
```

Position ticks should be sampled every 1–5 seconds for best feature quality.
Finer sampling increases file size but improves lane deviation and entropy accuracy.
