# DOTA 2 Laning Performance Embeddings

High-dimensional vector representations of laning phase behaviour, projected to 2D via UMAP.
Hero ID, player ID, and lane role are **excluded from the feature vector** — any clustering
on those axes is emergent, not imposed.

---

## Project structure

```
.
├── main.py                  ← CLI entry point (start here)
├── fetch_stratz.py          ← Stratz GraphQL API client
├── fetch_clarity.py         ← Clarity replay loader (JSON/Parquet/CSV)
├── feature_engineering.py   ← Feature extraction (~50 dims)
├── pipeline.py              ← RobustScaler → PCA → UMAP + KMeans
├── visualize.py             ← Interactive Plotly dashboard
├── requirements.txt
├── docs/
│   └── clarity_setup.md     ← Replay parsing setup guide
└── tools/
    └── ClarityExtractor.java ← Reference Clarity extractor
```

---

## Quick start

```bash
pip install -r requirements.txt

# Stratz only (recommended first run):
python main.py \
  --api-key YOUR_STRATZ_KEY \
  --steam-ids 76561198012345678 76561198087654321 \
  --matches-per-player 50

# Stratz + Clarity replays:
python main.py \
  --api-key YOUR_STRATZ_KEY \
  --steam-ids 76561198012345678 \
  --clarity-dir ./replays/parsed/ \
  --clarity-parser clarity

# Load from cache (no API calls):
python main.py --load-cache-only --stratz-cache ./stratz_cache
```

**Get a free Stratz API key:** https://stratz.com/api  
**Steam64 ID conversion:** `steam64 = opendota_account_id + 76561197960265728`

---

## Feature vector (~50 dimensions)

All features are from the **laning phase only** (minutes 0–10).

| Group | Features | Source |
|---|---|---|
| Farm trajectory | LH/deny rates, slope, acceleration, variance, early/late split | Stratz |
| Economic | GPM, XPM, networth slope, rate std | Stratz |
| Combat | K/D/A, KDA, kills at 10 min, first kill time | Stratz |
| Damage | Hero damage, healing, tower damage, damage ramp slope | Stratz |
| Vision | Observer/sentry counts, ward aggression score | Stratz |
| Purchases | Item count at 10 min, first buy time, buy rhythm | Stratz |
| APM | Mean actions/min, APM slope | Stratz |
| Composites | Farm efficiency, aggression score, support score, carry score, impact | Stratz |
| Positioning | Lane deviation, jungle fraction, movement entropy, forward positioning | Clarity |
| Abilities | Spell/ult casts, first cast time, cast rhythm | Clarity |
| Mechanics | Attack/move command ratio | Clarity |
| Runes | Early rune activity, rune pickup rate | Clarity |

Clarity features are zero-filled for rows without replay data — the pipeline handles mixed datasets.

---

## Pipeline

```
Raw features
    ↓
RobustScaler      (handles extreme skew between roles)
    ↓
[Optional PCA]    (--pca 20, recommended for n > 2000 samples)
    ↓
UMAP(2D)          (--n-neighbors 15 --min-dist 0.1)
    ↓
KMeans sweep      (k=4..14, best k by silhouette score)
```

---

## Outputs

| File | Contents |
|---|---|
| `laning_dashboard.html` | Self-contained interactive Plotly dashboard |
| `laning_vectors_highd.npy` | High-dimensional embedding (n_samples × n_features) |
| `laning_vectors_2d.npy` | 2D UMAP projection |
| `laning_pipeline.joblib` | Fitted pipeline (use `.transform()` for new data) |
| `laning_features.csv` | Raw feature matrix |
| `laning_metadata.csv` | Hero ID, player ID, role, win/loss (not in feature vector) |

---

## UMAP tuning guide

| Scenario | Recommended settings |
|---|---|
| Small dataset (<500) | `--n-neighbors 10 --min-dist 0.05` |
| Medium dataset (500–2000) | `--n-neighbors 15 --min-dist 0.1` (default) |
| Large dataset (>2000) | `--pca 20 --n-neighbors 25 --min-dist 0.1` |
| Emphasise local structure | `--n-neighbors 5 --min-dist 0.01` |
| Emphasise global structure | `--n-neighbors 50 --min-dist 0.25` |

---

## Validation interpretation

The dashboard shows 4 scatter views of the same 2D embedding:

1. **Role view** — if role clusters appear, the embedding captures role-defining behaviour
   (support vs carry playstyle) without being told role labels.
2. **Hero view** — hero clusters indicate hero-specific patterns (e.g., Meepo's CS style vs
   Pudge's roaming).
3. **Player view** — player clusters indicate individual style consistency across matches.
4. **Cluster view** — the KMeans assignments; check the profile chart to see whether
   individual clusters correspond to recognisable archetypes.

Strong separation in any of these views confirms the embedding has captured latent meaning.
