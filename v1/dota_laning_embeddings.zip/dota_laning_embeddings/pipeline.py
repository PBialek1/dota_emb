"""
pipeline.py
-----------
Embedding and clustering pipeline.

Steps
-----
1. RobustScaler      — handles the extreme skew between roles
                       (supports: 0 CS / 5 wards; carries: 80 CS / 0 wards)
2. Optional PCA      — pre-denoising; use when n_samples > 2000
3. UMAP              — non-linear manifold projection to 2D
4. KMeans sweep      — find optimal k by silhouette score

The high-dimensional scaled vector (after step 1/2) is the actual embedding.
The 2D UMAP projection is for visualisation only.
"""

import numpy as np
import pandas as pd
from sklearn.preprocessing import RobustScaler
from sklearn.decomposition import PCA
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import umap
import joblib
import logging
from typing import Dict, List, Optional, Tuple

logger = logging.getLogger(__name__)

# All feature columns fed to the embedding.
# Clarity columns are included — they'll be zero-filled for rows without replay data,
# which is fine because their contribution is diluted rather than noisy.
FEATURE_COLUMNS = [
    # Farm
    "lh_10", "denies_10", "gold_10", "xp_10",
    "lh_slope", "lh_variance", "lh_accel",
    "lh_early", "lh_late", "lh_consistency", "deny_rate",
    # Economy
    "gpm", "xpm", "gpm_slope", "gpm_std", "xpm_slope", "nw_slope",
    # Combat
    "total_kills", "total_deaths", "total_assists", "kda",
    "kills_10", "deaths_10", "first_kill_time",
    # Damage
    "hero_damage", "hero_healing", "tower_damage", "hdmg_slope",
    # Vision
    "obs_10", "sen_10", "obs_total", "sen_total", "ward_aggression",
    # Purchases
    "items_10", "first_purchase_time", "buy_interval_mean", "buy_interval_std",
    # APM
    "apm_mean", "apm_slope",
    # Composites
    "farm_efficiency", "aggression_score", "support_score", "carry_score", "impact_score",
    # Clarity — optional, zero-filled when absent
    "lane_deviation", "jungle_fraction", "move_entropy",
    "mean_dist_from_fountain", "pos_variance",
    "total_casts_10", "ult_casts_10", "spell_casts_10",
    "first_cast_time", "cast_interval_mean", "cast_interval_std",
    "attack_move_ratio", "early_rune_activity", "rune_pickup_rate",
]


class LaningEmbeddingPipeline:
    """
    Fit the full embedding pipeline on a dataset, then call transform() for new data.

    Usage
    -----
        pipe = LaningEmbeddingPipeline(n_neighbors=15, min_dist=0.1)
        X_scaled, embedding = pipe.fit_transform(features_df)
        pipe.save("laning_pipeline.joblib")

    After fit_transform():
        pipe.feature_columns   — list of columns actually used (subset of FEATURE_COLUMNS)
        X_scaled               — high-dim representation  (n_samples, n_feats)
        embedding              — 2D UMAP projection       (n_samples, 2)
    """

    def __init__(
        self,
        n_neighbors: int = 15,
        min_dist: float = 0.1,
        umap_metric: str = "euclidean",
        pca_components: Optional[int] = None,
        random_state: int = 42,
    ):
        self.n_neighbors = n_neighbors
        self.min_dist = min_dist
        self.umap_metric = umap_metric
        self.pca_components = pca_components
        self.random_state = random_state

        self.scaler: Optional[RobustScaler] = None
        self.pca: Optional[PCA] = None
        self.reducer: Optional[umap.UMAP] = None
        self.feature_columns: Optional[List[str]] = None

    # ------------------------------------------------------------------

    def _prepare(self, features_df: pd.DataFrame) -> np.ndarray:
        cols = [c for c in FEATURE_COLUMNS if c in features_df.columns]
        self.feature_columns = cols
        X = features_df[cols].copy().fillna(0.0)

        # Clip 1st–99th percentile per column to tame extreme outliers
        for col in X.columns:
            lo, hi = X[col].quantile(0.01), X[col].quantile(0.99)
            if hi > lo:
                X[col] = X[col].clip(lo, hi)

        return X.values.astype(float)

    # ------------------------------------------------------------------

    def fit_transform(self, features_df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """
        Fit the pipeline and return (X_scaled, embedding_2d).

        X_scaled     → the high-dimensional embedding (use for clustering, similarity search)
        embedding_2d → 2D UMAP projection              (use for visualisation)
        """
        X = self._prepare(features_df)
        logger.info(f"Fitting pipeline: {X.shape[0]} samples × {X.shape[1]} features")

        # 1. Scale
        self.scaler = RobustScaler()
        X_scaled = self.scaler.fit_transform(X)

        # 2. Optional PCA (recommended for n_samples > 2000)
        if self.pca_components and self.pca_components < X_scaled.shape[1]:
            self.pca = PCA(n_components=self.pca_components, random_state=self.random_state)
            X_scaled = self.pca.fit_transform(X_scaled)
            ev = self.pca.explained_variance_ratio_.sum()
            logger.info(f"PCA → {self.pca_components} components, {ev:.1%} variance explained")

        # 3. UMAP
        logger.info(f"UMAP: n_neighbors={self.n_neighbors}, min_dist={self.min_dist}")
        self.reducer = umap.UMAP(
            n_components=2,
            n_neighbors=self.n_neighbors,
            min_dist=self.min_dist,
            metric=self.umap_metric,
            random_state=self.random_state,
            low_memory=False,
        )
        embedding_2d = self.reducer.fit_transform(X_scaled)
        logger.info("UMAP complete")

        return X_scaled, embedding_2d

    def transform(self, features_df: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
        """Transform new data with a fitted pipeline (no re-fitting)."""
        X = self._prepare(features_df)
        X_scaled = self.scaler.transform(X)
        if self.pca:
            X_scaled = self.pca.transform(X_scaled)
        return X_scaled, self.reducer.transform(X_scaled)

    def save(self, path: str):
        joblib.dump(self, path)
        logger.info(f"Pipeline saved → {path}")

    @staticmethod
    def load(path: str) -> "LaningEmbeddingPipeline":
        return joblib.load(path)


# ---------------------------------------------------------------------------
# Clustering
# ---------------------------------------------------------------------------

def cluster_sweep(
    X_scaled: np.ndarray,
    metadata_df: pd.DataFrame,
    k_min: int = 4,
    k_max: int = 14,
) -> Tuple[np.ndarray, Dict, Dict]:
    """
    Sweep KMeans over k_min..k_max, select best k by silhouette score.

    Returns
    -------
    cluster_labels   : np.ndarray of shape (n_samples,)
    cluster_stats    : dict  {cluster_id → composition summary}
    silhouette_scores: dict  {k → score}
    """
    scores: Dict[int, float] = {}
    for k in range(k_min, k_max + 1):
        labels = KMeans(n_clusters=k, random_state=42, n_init=10).fit_predict(X_scaled)
        s = silhouette_score(X_scaled, labels)
        scores[k] = round(float(s), 4)
        logger.info(f"  k={k:2d}  silhouette={s:.4f}")

    best_k = max(scores, key=scores.get)
    logger.info(f"Best k={best_k}  (silhouette={scores[best_k]:.4f})")

    final_labels = KMeans(n_clusters=best_k, random_state=42, n_init=10).fit_predict(X_scaled)

    cluster_stats: Dict[int, Dict] = {}
    for cid in range(best_k):
        mask = final_labels == cid
        sub  = metadata_df[mask]
        cluster_stats[cid] = {
            "size":           int(mask.sum()),
            "hero_id_top5":   sub["hero_id"].value_counts().head(5).to_dict(),
            "lane_role_dist": sub["lane_role"].value_counts(normalize=True).round(3).to_dict(),
            "player_top5":    sub["account_id"].value_counts().head(5).to_dict(),
            "win_rate":       float(sub["win"].mean()) if "win" in sub.columns else None,
        }

    return final_labels, cluster_stats, scores
