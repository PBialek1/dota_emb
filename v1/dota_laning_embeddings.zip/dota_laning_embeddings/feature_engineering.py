"""
feature_engineering.py
-----------------------
Unified feature extraction from Stratz API data with optional
Clarity replay enrichment.

Output: ~50-dimensional vector per player-match.

IMPORTANT: hero_id, account_id, and lane_role are stored in METADATA ONLY.
They are never input features. Any clustering on those axes is emergent.

Feature groups
--------------
From Stratz (always available):
  Farm trajectory    - per-minute LH/deny rates, slopes, acceleration, variance
  Economic rates     - GPM, XPM, networth slope, rate std
  Combat             - kills/deaths/assists in lane, KDA, first kill time
  Damage             - hero damage dealt/taken, damage ramp slope
  Vision             - observer/sentry counts, ward aggression score
  Healing/objectives - hero healing, tower damage
  Purchases          - first item timing, item count, buy rhythm
  APM                - mean and trend (Stratz actionsPerMinute)
  Composites         - farm efficiency, aggression, support, carry, impact

From Clarity (merged when available, zero-filled otherwise):
  Positioning        - lane deviation, jungle fraction, movement entropy
  Positioning        - forward positioning score, position variance
  Abilities          - spell/ult casts in lane, first cast time, rhythm
  Mechanics          - attack/move command ratio
  Runes              - early rune activity, rune pickup rate
"""

import numpy as np
import pandas as pd
from typing import Dict, List, Optional, Tuple
import logging

logger = logging.getLogger(__name__)

LANING_MIN = 10
LANING_SEC = LANING_MIN * 60


# ---------------------------------------------------------------------------
# Time-series helpers
# ---------------------------------------------------------------------------

def _ts_slice(arr: list, start: int, end: int) -> np.ndarray:
    if not arr:
        return np.array([0.0])
    end = min(end, len(arr))
    start = min(start, end)
    return np.array(arr[start:end], dtype=float)


def _slope(arr: np.ndarray) -> float:
    if len(arr) < 2:
        return 0.0
    return float(np.polyfit(np.arange(len(arr)), arr, 1)[0])


def _count_before(log: list, cutoff_sec: int) -> int:
    return sum(1 for e in (log or []) if e.get("time", 1e9) < cutoff_sec)


# ---------------------------------------------------------------------------
# Stratz feature extractor
# ---------------------------------------------------------------------------

def extract_stratz_features(player: Dict, match: Dict) -> Optional[Dict]:
    """
    Extract laning features from one Stratz player object.
    Returns {'features': {...}, 'metadata': {...}} or None if data is too sparse.
    """
    stats    = player.get("stats")        or {}
    playback = player.get("playbackData") or {}

    # Per-minute arrays (index = minute number)
    lh_pm   = stats.get("lastHitPerMinute",   []) or []
    dn_pm   = stats.get("deniesPerMinute",     []) or []
    gpm_arr = stats.get("goldPerMinute",       []) or []
    xpm_arr = stats.get("experiencePerMinute", []) or []
    nw_arr  = stats.get("networthPerMinute",   []) or []
    hdmg_pm = stats.get("heroDamagePerMinute", []) or []
    apm_arr = stats.get("actionsPerMinute",    []) or []

    if len(gpm_arr) < 6:
        return None

    t = min(LANING_MIN, len(gpm_arr) - 1)   # effective laning end (minutes)

    # ── Farm ─────────────────────────────────────────────────────────────────
    lh_10   = float(sum(lh_pm[:t+1]))
    dn_10   = float(sum(dn_pm[:t+1]))
    gold_10 = float(sum(gpm_arr[:t+1]))
    xp_10   = float(sum(xpm_arr[:t+1]))

    lh_ts   = _ts_slice(lh_pm,   0, t+1)
    gpm_ts  = _ts_slice(gpm_arr, 0, t+1)
    xpm_ts  = _ts_slice(xpm_arr, 0, t+1)
    dn_ts   = _ts_slice(dn_pm,   0, t+1)
    nw_ts   = _ts_slice(nw_arr,  0, t+1)

    lh_slope    = _slope(lh_ts)
    lh_variance = float(np.var(lh_ts))
    lh_accel    = _slope(np.diff(lh_ts)) if len(lh_ts) > 2 else 0.0
    gpm_slope   = _slope(gpm_ts)
    gpm_std     = float(np.std(gpm_ts))
    xpm_slope   = _slope(xpm_ts)
    nw_slope    = _slope(nw_ts)

    # Early (0-4 min) vs late (5-10 min) CS rate
    lh_early = float(np.mean(lh_ts[:5]))  if len(lh_ts) >= 5 else 0.0
    lh_late  = float(np.mean(lh_ts[5:]))  if len(lh_ts) >  5 else 0.0
    lh_consistency = lh_early / max(0.1, lh_late)   # ~1.0 = even; >1 = front-loaded

    deny_rate = dn_10 / max(1.0, lh_10)

    # ── APM ──────────────────────────────────────────────────────────────────
    apm_ts    = _ts_slice(apm_arr, 0, t+1)
    apm_mean  = float(np.mean(apm_ts)) if len(apm_ts) else 0.0
    apm_slope = _slope(apm_ts)

    # ── Combat ───────────────────────────────────────────────────────────────
    kills   = int(player.get("kills",   0) or 0)
    deaths  = int(player.get("deaths",  0) or 0)
    assists = int(player.get("assists", 0) or 0)
    kda     = (kills + assists) / max(1, deaths)

    kill_events  = stats.get("killEvents",  []) or []
    death_events = stats.get("deathEvents", []) or []
    kills_10  = _count_before(kill_events,  LANING_SEC)
    deaths_10 = _count_before(death_events, LANING_SEC)

    first_kill_time = (
        min((e["time"] for e in kill_events if e.get("time", 1e9) < LANING_SEC), default=LANING_SEC)
    )

    # ── Damage ───────────────────────────────────────────────────────────────
    hero_dmg  = float(player.get("heroDamage",  0) or 0)
    hero_heal = float(player.get("heroHealing", 0) or 0)
    tower_dmg = float(player.get("towerDamage", 0) or 0)
    hdmg_ts   = _ts_slice(hdmg_pm, 0, t+1)
    hdmg_slope = _slope(hdmg_ts)   # positive = ramping aggression

    # ── Vision ───────────────────────────────────────────────────────────────
    wards     = stats.get("wardDestinationEvents") or []
    obs_10    = sum(1 for w in wards if w.get("time", 1e9) < LANING_SEC and w.get("type") == "OBSERVER")
    sen_10    = sum(1 for w in wards if w.get("time", 1e9) < LANING_SEC and w.get("type") == "SENTRY")
    obs_total = sum(1 for w in wards if w.get("type") == "OBSERVER")
    sen_total = sum(1 for w in wards if w.get("type") == "SENTRY")

    MAP_CENTER = 8192
    lane_obs = [w for w in wards if w.get("time", 1e9) < LANING_SEC and w.get("type") == "OBSERVER"]
    ward_aggression = float(np.mean([
        abs(w.get("positionX", MAP_CENTER) - MAP_CENTER) + abs(w.get("positionY", MAP_CENTER) - MAP_CENTER)
        for w in lane_obs
    ])) if lane_obs else 0.0

    # ── Purchases ────────────────────────────────────────────────────────────
    purchases = (playback.get("itemPurchaseEvents") or [])
    items_10  = _count_before(purchases, LANING_SEC)
    buy_times = sorted(p["time"] for p in purchases if p.get("time", 1e9) < LANING_SEC)
    first_buy = buy_times[0] if buy_times else LANING_SEC

    if len(buy_times) >= 2:
        ivls = [buy_times[i+1] - buy_times[i] for i in range(len(buy_times)-1)]
        buy_interval_mean = float(np.mean(ivls))
        buy_interval_std  = float(np.std(ivls))
    else:
        buy_interval_mean = buy_interval_std = 0.0

    # ── Composite scores ─────────────────────────────────────────────────────
    gpm_total = float(player.get("goldPerMinute")       or (gold_10 / LANING_MIN))
    xpm_total = float(player.get("experiencePerMinute") or (xp_10  / LANING_MIN))

    farm_efficiency  = (lh_10 + dn_10) / LANING_MIN
    aggression_score = kills_10 * 2 + assists - deaths_10
    support_score    = obs_total * 3 + sen_total * 2 + hero_heal / 200.0
    carry_score      = lh_10 / 10.0 + gpm_total / 100.0 + tower_dmg / 500.0
    impact_score     = float(player.get("imp") or 0.0)

    # ── Assemble ─────────────────────────────────────────────────────────────
    features = dict(
        lh_10=lh_10, denies_10=dn_10, gold_10=gold_10, xp_10=xp_10,
        lh_slope=lh_slope, lh_variance=lh_variance, lh_accel=lh_accel,
        lh_early=lh_early, lh_late=lh_late, lh_consistency=lh_consistency,
        deny_rate=deny_rate,
        gpm=gpm_total, xpm=xpm_total,
        gpm_slope=gpm_slope, gpm_std=gpm_std,
        xpm_slope=xpm_slope, nw_slope=nw_slope,
        total_kills=kills, total_deaths=deaths, total_assists=assists,
        kda=kda, kills_10=kills_10, deaths_10=deaths_10,
        first_kill_time=first_kill_time,
        hero_damage=hero_dmg, hero_healing=hero_heal, tower_damage=tower_dmg,
        hdmg_slope=hdmg_slope,
        obs_10=obs_10, sen_10=sen_10, obs_total=obs_total, sen_total=sen_total,
        ward_aggression=ward_aggression,
        items_10=items_10, first_purchase_time=first_buy,
        buy_interval_mean=buy_interval_mean, buy_interval_std=buy_interval_std,
        apm_mean=apm_mean, apm_slope=apm_slope,
        farm_efficiency=farm_efficiency, aggression_score=aggression_score,
        support_score=support_score, carry_score=carry_score,
        impact_score=impact_score,
    )

    metadata = dict(
        match_id=match.get("id"),
        account_id=player.get("steamAccountId"),
        hero_id=player.get("heroId"),
        lane=player.get("lane"),
        lane_role=player.get("laneRole"),
        player_slot=int(player.get("playerSlot") or 0),
        win=int(bool(match.get("didRadiantWin"))),
    )

    return {"features": features, "metadata": metadata}


# ---------------------------------------------------------------------------
# Dataset builder
# ---------------------------------------------------------------------------

def build_dataset(
    matches: List[Dict],
    clarity_index: Optional[Dict] = None,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Build feature and metadata DataFrames from all matches.

    Args:
        matches:       List of Stratz match dicts.
        clarity_index: Optional dict from fetch_clarity.build_clarity_feature_index().
                       When provided, Clarity features are merged for matching
                       (match_id, player_slot) pairs. Rows without a Clarity match
                       get NaN for those columns (filled with 0 in the pipeline).

    Returns:
        (features_df, metadata_df) — same row order, safe to zip/concat.
    """
    feat_rows, meta_rows = [], []

    for match in matches:
        for player in match.get("players", []):
            result = extract_stratz_features(player, match)
            if not result:
                continue

            if clarity_index:
                key = (result["metadata"]["match_id"],
                       result["metadata"]["player_slot"])
                clarity_feats = clarity_index.get(key)
                if clarity_feats:
                    result["features"].update(clarity_feats)

            feat_rows.append(result["features"])
            meta_rows.append(result["metadata"])

    features_df = pd.DataFrame(feat_rows)
    metadata_df = pd.DataFrame(meta_rows)

    n_clarity = sum(1 for r in feat_rows if "lane_deviation" in r) if clarity_index else 0
    logger.info(
        f"Dataset: {len(features_df)} records × {len(features_df.columns)} features "
        f"({n_clarity} enriched with Clarity)"
    )
    return features_df, metadata_df
